import { Button } from "@/components/ui/button";
import { APP_LOGO } from "@/const";
import { CheckCircle, Clock, MessageCircle, ArrowLeft, Phone, Mail } from "lucide-react";
import { useLocation } from "wouter";

export default function ThankYou() {
  const [, setLocation] = useLocation();
  const whatsappUrl = "https://api.whatsapp.com/send/?phone=5521997941008&text=Ol%C3%A1%21+Gostaria+de+falar+com+um+consultor+sobre+registro+de+marcas.&type=phone_number&app_absent=0";

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-background via-purple-50 to-orange-50">
      {/* Header Simples */}
      <header className="bg-gradient-to-r from-primary to-purple-600 py-4 shadow-lg">
        <div className="container">
          <div className="flex items-center justify-between">
            <img src={APP_LOGO} alt="MarcaFácil.legal" className="h-10 md:h-12" />
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setLocation("/")}
              className="text-white hover:bg-white/20"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Voltar ao início
            </Button>
          </div>
        </div>
      </header>

      {/* Conteúdo Principal */}
      <main className="flex-1 flex items-center justify-center px-4 py-12">
        <div className="max-w-3xl w-full">
          {/* Card Principal */}
          <div className="bg-white rounded-3xl shadow-2xl p-8 md:p-12 text-center animate-fade-in">
            {/* Ícone de Sucesso */}
            <div className="flex justify-center mb-6">
              <div className="relative">
                <div className="absolute inset-0 bg-green-500 rounded-full blur-2xl opacity-30 animate-pulse" />
                <CheckCircle className="h-24 w-24 text-green-500 relative animate-scale-in" />
              </div>
            </div>

            {/* Título */}
            <h1 className="text-4xl md:text-5xl font-extrabold mb-4 bg-gradient-to-r from-primary to-purple-600 bg-clip-text text-transparent">
              Obrigado pelo seu contato!
            </h1>

            {/* Mensagem de Confirmação */}
            <p className="text-xl md:text-2xl text-muted-foreground mb-8 font-medium">
              Recebemos sua solicitação de consulta gratuita com sucesso.
            </p>

            {/* Card de Expectativa */}
            <div className="bg-gradient-to-br from-purple-50 to-orange-50 rounded-2xl p-6 mb-8 border-2 border-primary/20">
              <div className="flex items-center justify-center gap-3 mb-3">
                <Clock className="h-6 w-6 text-primary" />
                <h2 className="text-xl font-bold text-primary">Próximos Passos</h2>
              </div>
              <p className="text-base text-muted-foreground leading-relaxed">
                Nossa equipe de especialistas entrará em contato com você em até <strong className="text-primary">24 horas úteis</strong> para agendar sua consulta gratuita e esclarecer todas as suas dúvidas sobre o registro da sua marca.
              </p>
            </div>

            {/* Lista de Próximos Passos */}
            <div className="bg-gray-50 rounded-2xl p-6 mb-8 text-left">
              <h3 className="text-lg font-bold mb-4 text-center">O que acontece agora?</h3>
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="flex-shrink-0 w-8 h-8 bg-primary text-white rounded-full flex items-center justify-center font-bold">
                    1
                  </div>
                  <div>
                    <p className="font-semibold text-foreground">Análise da sua solicitação</p>
                    <p className="text-sm text-muted-foreground">Revisaremos as informações fornecidas sobre sua marca</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="flex-shrink-0 w-8 h-8 bg-primary text-white rounded-full flex items-center justify-center font-bold">
                    2
                  </div>
                  <div>
                    <p className="font-semibold text-foreground">Contato do especialista</p>
                    <p className="text-sm text-muted-foreground">Um consultor entrará em contato via WhatsApp ou telefone</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="flex-shrink-0 w-8 h-8 bg-primary text-white rounded-full flex items-center justify-center font-bold">
                    3
                  </div>
                  <div>
                    <p className="font-semibold text-foreground">Consulta gratuita personalizada</p>
                    <p className="text-sm text-muted-foreground">Tire todas as dúvidas e receba orientações sobre o processo</p>
                  </div>
                </div>
              </div>
            </div>

            {/* CTA WhatsApp */}
            <div className="mb-6">
              <p className="text-sm text-muted-foreground mb-4">
                Precisa falar conosco agora? Entre em contato diretamente:
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button
                  size="lg"
                  onClick={() => window.open(whatsappUrl, '_blank')}
                  className="h-14 px-8 bg-gradient-to-r from-accent to-orange-500 text-accent-foreground hover:shadow-2xl hover:scale-105 transition-all font-bold gap-3"
                >
                  <MessageCircle className="h-5 w-5" />
                  Falar no WhatsApp
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  onClick={() => setLocation("/")}
                  className="h-14 px-8 font-bold gap-3 border-2"
                >
                  <ArrowLeft className="h-5 w-5" />
                  Voltar ao site
                </Button>
              </div>
            </div>

            {/* Informações de Contato */}
            <div className="border-t pt-6 mt-6">
              <p className="text-sm text-muted-foreground mb-3">Outras formas de contato:</p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center items-center text-sm">
                <a href="tel:+552199794-1008" className="flex items-center gap-2 text-primary hover:underline">
                  <Phone className="h-4 w-4" />
                  (21) 99794-1008
                </a>
                <a href="mailto:atendimento@marcafacil.legal" className="flex items-center gap-2 text-primary hover:underline">
                  <Mail className="h-4 w-4" />
                  atendimento@marcafacil.legal
                </a>
              </div>
            </div>
          </div>

          {/* Mensagem de Rodapé */}
          <p className="text-center text-sm text-muted-foreground mt-6">
            Verifique sua caixa de entrada e spam para não perder nenhuma comunicação nossa.
          </p>
        </div>
      </main>

      {/* Footer Simples */}
      <footer className="bg-[#3a4a5c] text-white py-6">
        <div className="container text-center">
          <p className="text-sm">
            © {new Date().getFullYear()} MARCAFACIL.LEGAL — Todos os Direitos Reservados.
          </p>
        </div>
      </footer>
    </div>
  );
}
