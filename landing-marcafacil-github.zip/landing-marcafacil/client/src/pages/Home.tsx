import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetClose,
} from "@/components/ui/sheet";
import * as VisuallyHidden from "@radix-ui/react-visually-hidden";
import { APP_LOGO, APP_LOGO_CIRCLE } from "@/const";
import { useState, useEffect } from "react";
import { CheckCircle2, Users, Shield, DollarSign, Star, MessageCircle, TrendingUp, Award, Clock, Sparkles, ArrowRight, Menu, X } from "lucide-react";
import { toast } from "sonner";

// Componente Trustindex Widget - Método Alternativo para React
function TrustindexWidget() {
  // Usando método alternativo conforme documentação oficial:
  // Script base já está no index.html
  // Aqui usamos apenas a div com src específico (atributo customizado do Trustindex)
  return (
    <div 
      {...({ src: "https://cdn.trustindex.io/loader.js?b19746558f782539627633c070b" } as any)}
      className="min-h-[400px]"
    ></div>
  );
}

export default function Home() {
  const [brandName, setBrandName] = useState("");
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    whatsapp: "",
    brandName: ""
  });
  const [isVisible, setIsVisible] = useState(false);
  const [activeSection, setActiveSection] = useState("");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const whatsappUrl = "https://api.whatsapp.com/send/?phone=5521997941008&text=Ol%C3%A1%21+Gostaria+de+falar+com+um+consultor+sobre+registro+de+marcas.&type=phone_number&app_absent=0";

  useEffect(() => {
    setIsVisible(true);
  }, []);

  const handleVerify = (e: React.FormEvent) => {
    e.preventDefault();
    const message = encodeURIComponent(`Olá! Gostaria de verificar se o nome "${brandName}" pode ser registrado no INPI.`);
    window.open(`https://api.whatsapp.com/send/?phone=5521997941008&text=${message}&type=phone_number&app_absent=0`, '_blank');
  };

  const handleConsultation = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Netlify Forms: submeter via fetch
    const form = e.target as HTMLFormElement;
    const formData = new FormData(form);
    
    fetch('/', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams(formData as any).toString(),
    })
      .then(() => {
        // Sucesso: mostrar toast e redirecionar
        toast.success('Consulta agendada com sucesso! Entraremos em contato em breve.');
        // Limpar formulário
        setFormData({ name: '', email: '', whatsapp: '', brandName: '' });
        // Opcional: redirecionar para página de obrigado após 2s
        setTimeout(() => {
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }, 2000);
      })
      .catch((error) => {
        toast.error('Erro ao enviar formulário. Tente novamente.');
        console.error('Erro:', error);
      });
  };

  // Depoimentos agora são carregados via Trustindex

  // Carrossel de testimonials removido - agora usando Trustindex

  const stats = [
    { icon: Award, value: "15+", label: "Anos de Experiência" },
    { icon: CheckCircle2, value: "1.500+", label: "Marcas Registradas" },
    { icon: TrendingUp, value: "GARANTIA", label: "de Aprovação" },
    { icon: Clock, value: "24h", label: "Resposta Inicial" }
  ];

  const processSteps = [
    {
      number: 1,
      title: "Definição e Classificação da Marca",
      description: "Identificamos sua marca e definimos o segmento de atuação conforme a Classificação de Nice, padrão internacional adotado pelo INPI."
    },
    {
      number: 2,
      title: "Busca de Anterioridades & Análise de Viabilidade",
      description: "Nossa equipe realiza busca detalhada no banco de dados do INPI, avaliando as chances reais de aprovação e verificando marcas similares."
    },
    {
      number: 3,
      title: "Depósito da Marca",
      description: "Organizamos a documentação, você assina a procuração, e damos entrada oficial no pedido junto ao INPI com número de processo."
    },
    {
      number: 4,
      title: "Exame Formal",
      description: "O INPI verifica requisitos técnicos: classificação, qualidade da imagem, documentos e estrutura do processo."
    },
    {
      number: 5,
      title: "Publicação para Fins de Oposição",
      description: "O INPI publica o pedido na RPI. Terceiros têm 60 dias para apresentar objeções ao registro."
    },
    {
      number: 6,
      title: "Exame de Mérito",
      description: "Análise aprofundada do INPI: busca de anterioridades, avaliação de oposições e decisão de deferimento ou indeferimento."
    },
    {
      number: 7,
      title: "Registro da Marca",
      description: "Com a aprovação, o INPI emite automaticamente o CERTIFICADO DE REGISTRO, válido por 10 anos."
    },
    {
      number: 8,
      title: "Renovação & Monitoramento",
      description: "Monitoramos marcas similares no INPI e te avisamos quando for hora de renovar seu registro."
    }
  ];

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
      setMobileMenuOpen(false); // Fecha o menu mobile após clicar
    }
  };

  useEffect(() => {
    const handleScroll = () => {
      const sections = ['por-que-escolher', 'passo-a-passo', 'registrar-marca', 'consulta-gratuita'];
      const scrollPosition = window.scrollY + 100;

      for (const sectionId of sections) {
        const element = document.getElementById(sectionId);
        if (element) {
          const { offsetTop, offsetHeight } = element;
          if (scrollPosition >= offsetTop && scrollPosition < offsetTop + offsetHeight) {
            setActiveSection(sectionId);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-secondary/20 to-white">
      {/* Header - Design Original */}
      <header className="bg-[#663399] sticky top-0 z-50 shadow-lg">
        <div className="container py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <img src={APP_LOGO} alt="MarcaFácil.legal" className="h-12 w-auto cursor-pointer" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} />
            </div>
            
            {/* Menu Desktop - Navegação por Seções */}
            <nav className="hidden lg:flex items-center gap-6">
              <button 
                onClick={() => scrollToSection('por-que-escolher')}
                className={`text-white font-semibold hover:text-white/80 transition-colors text-sm uppercase ${activeSection === 'por-que-escolher' ? 'border-b-2 border-white' : ''}`}
              >
                Por que escolher
              </button>
              <button 
                onClick={() => scrollToSection('passo-a-passo')}
                className={`text-white font-semibold hover:text-white/80 transition-colors text-sm uppercase ${activeSection === 'passo-a-passo' ? 'border-b-2 border-white' : ''}`}
              >
                Passo a Passo
              </button>
              <button 
                onClick={() => scrollToSection('registrar-marca')}
                className={`text-white font-semibold hover:text-white/80 transition-colors text-sm uppercase ${activeSection === 'registrar-marca' ? 'border-b-2 border-white' : ''}`}
              >
                Quero registrar minha marca
              </button>
              <button 
                onClick={() => scrollToSection('consulta-gratuita')}
                className={`text-white font-semibold hover:text-white/80 transition-colors text-sm uppercase ${activeSection === 'consulta-gratuita' ? 'border-b-2 border-white' : ''}`}
              >
                Quero uma consulta gratuita
              </button>
            </nav>

            <Button
              size="lg"
              onClick={() => window.open(whatsappUrl, '_blank')}
              className="hidden lg:flex bg-gradient-to-r from-[#ff6b35] to-[#f7931e] text-white hover:shadow-xl transition-all font-bold uppercase text-sm px-6 rounded-full"
            >
              Fale com um Especialista
            </Button>

            {/* Botão Hamburger Mobile */}
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setMobileMenuOpen(true)}
              className="lg:hidden text-white hover:bg-white/10 h-10 w-10"
              aria-label="Abrir menu"
            >
              <Menu className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </header>

      {/* Mobile Menu Drawer */}
      <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
        <SheetContent side="left" className="w-full bg-gradient-to-b from-primary to-purple-700 text-white border-0">
          <VisuallyHidden.Root>
            <SheetTitle>Menu de Navegação</SheetTitle>
          </VisuallyHidden.Root>
          <SheetHeader className="border-b border-white/20 pb-4 mb-6">
            <div className="flex items-center justify-between">
              <img src={APP_LOGO} alt="MarcaFácil.legal" className="h-10 w-auto" />
              <SheetClose asChild>
                <Button variant="ghost" size="sm" className="text-white hover:bg-white/10 p-2">
                  <X className="h-5 w-5" />
                </Button>
              </SheetClose>
            </div>
          </SheetHeader>

          <nav className="flex flex-col gap-2">
            <button
              onClick={() => scrollToSection('por-que-escolher')}
              className={`w-full text-left px-4 py-3 rounded-lg font-semibold transition-all hover:bg-white/10 ${
                activeSection === 'por-que-escolher' ? 'bg-white/20' : ''
              }`}
            >
              Por que escolher
            </button>
            <button
              onClick={() => scrollToSection('passo-a-passo')}
              className={`w-full text-left px-4 py-3 rounded-lg font-semibold transition-all hover:bg-white/10 ${
                activeSection === 'passo-a-passo' ? 'bg-white/20' : ''
              }`}
            >
              Passo a Passo
            </button>
            <button
              onClick={() => scrollToSection('registrar-marca')}
              className={`w-full text-left px-4 py-3 rounded-lg font-semibold transition-all hover:bg-white/10 ${
                activeSection === 'registrar-marca' ? 'bg-white/20' : ''
              }`}
            >
              Quero registrar minha marca
            </button>
            <button
              onClick={() => scrollToSection('consulta-gratuita')}
              className={`w-full text-left px-4 py-3 rounded-lg font-semibold transition-all hover:bg-white/10 ${
                activeSection === 'consulta-gratuita' ? 'bg-white/20' : ''
              }`}
            >
              Quero uma consulta gratuita
            </button>
          </nav>

          {/* Divider */}


          {/* CTA WhatsApp */}
          <div className="mt-8">
            <Button
              onClick={() => {
                window.open(whatsappUrl, '_blank');
                setMobileMenuOpen(false);
              }}
              className="w-full h-12 bg-gradient-to-r from-[#ff6b35] to-[#f7931e] text-white hover:shadow-xl transition-all font-bold gap-2 rounded-lg"
            >
              <MessageCircle className="h-5 w-5" />
              Falar com Especialista
            </Button>
          </div>
        </SheetContent>
      </Sheet>

      {/* Hero Section */}
      <section className="relative py-12 md:py-20 lg:py-32 overflow-hidden px-4">
        {/* Background Decorations */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-0 right-0 w-96 h-96 bg-primary/5 rounded-full blur-3xl animate-pulse" />
          <div className="absolute bottom-0 left-0 w-96 h-96 bg-accent/5 rounded-full blur-3xl animate-pulse delay-1000" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-to-r from-primary/5 to-accent/5 rounded-full blur-3xl" />
        </div>

        <div className="container relative">
          <div className={`max-w-4xl mx-auto text-center transition-all duration-1000 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-primary/10 rounded-full mb-6 animate-fade-in">
              <Sparkles className="h-4 w-4 text-primary" />
              <span className="text-sm font-semibold text-primary">Fácil como a vida deveria ser</span>
            </div>

            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-extrabold text-foreground mb-4 md:mb-6 leading-tight">
              Registrar sua marca é{" "}
              <span className="bg-gradient-to-r from-primary via-purple-600 to-accent bg-clip-text text-transparent animate-gradient">
                mais fácil
              </span>
              {" "}do que você imagina
            </h1>
            
            <p className="text-base sm:text-lg md:text-xl lg:text-2xl text-muted-foreground mb-8 md:mb-12 font-medium">
              Proteja sua marca e garanta exclusividade no mercado com nosso serviço especializado.
            </p>

            {/* CTA Principal */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-6 md:mb-10">
              <Button
                size="lg"
                onClick={() => {
                  const section = document.getElementById('consulta-gratuita');
                  if (section) {
                    section.scrollIntoView({ behavior: 'smooth', block: 'start' });
                  }
                }}
                className="h-16 px-12 bg-gradient-to-r from-accent to-orange-500 text-accent-foreground hover:shadow-2xl hover:scale-105 transition-all text-xl font-extrabold rounded-xl gap-3 w-full sm:w-auto"
              >
                <MessageCircle className="h-6 w-6" />
                Verificar agora
                <ArrowRight className="h-6 w-6" />
              </Button>
            </div>

            {/* Selo de Credibilidade */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3 sm:gap-6 mb-6 md:mb-10 text-sm sm:text-base">
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1 text-yellow-500">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 fill-current animate-pulse" style={{ animationDelay: `${i * 100}ms` }} />
                  ))}
                </div>
                <span className="text-muted-foreground font-semibold">5.0 no Google</span>
              </div>
              <div className="h-1 w-1 rounded-full bg-muted-foreground hidden sm:block" />
              <span className="text-muted-foreground font-semibold">15 anos de experiência</span>
              <div className="h-1 w-1 rounded-full bg-muted-foreground hidden sm:block" />
              <span className="text-muted-foreground font-semibold">1.500+ marcas registradas</span>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-gradient-to-r from-primary via-purple-600 to-primary relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxwYXRoIGQ9Ik0zNiAxOGMzLjMxNCAwIDYgMi42ODYgNiA2cy0yLjY4NiA2LTYgNi02LTIuNjg2LTYtNiAyLjY4Ni02IDYtNnoiIHN0cm9rZT0iI2ZmZiIgc3Ryb2tlLW9wYWNpdHk9Ii4wNSIvPjwvZz48L3N2Zz4=')] opacity-10"></div>
        <div className="container relative">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center group">
                <div className="inline-flex items-center justify-center w-16 h-16 mb-4 rounded-2xl bg-white/10 backdrop-blur-sm group-hover:bg-white/20 transition-all group-hover:scale-110">
                  <stat.icon className="h-8 w-8 text-white" />
                </div>
                <div className="text-4xl md:text-5xl font-extrabold text-white mb-2">{stat.value}</div>
                <div className="text-white/80 font-medium">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Por que escolher - Seção 1 */}
      <section id="por-que-escolher" className="py-20 relative scroll-mt-20">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-extrabold mb-4 bg-gradient-to-r from-primary to-purple-600 bg-clip-text text-transparent">
              Por que escolher MARCAFACIL.LEGAL?
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Na vida do empreendedor tem muitas dificuldades. Sua marca não precisa ser mais uma.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {[
              {
                icon: Users,
                title: "Atendimento humano e digital",
                description: "Atendimento especializado que combina tecnologia e suporte humano para garantir a melhor experiência",
                gradient: "from-blue-500 to-cyan-500"
              },
              {
                icon: Shield,
                title: "Garantia de aprovação",
                description: "Analisamos viabilidade antes de iniciar o processo, garantindo sucesso no registro",
                gradient: "from-purple-500 to-pink-500"
              },
              {
                icon: CheckCircle2,
                title: "Transparência total no custo",
                description: "Sem taxas ocultas, você sabe exatamente o que vai pagar desde o início",
                gradient: "from-orange-500 to-red-500"
              }
            ].map((benefit, index) => (
              <Card key={index} className="border-0 shadow-2xl bg-white hover:shadow-3xl transition-all duration-300 hover:-translate-y-2 group overflow-hidden relative">
                <div className={`absolute inset-0 bg-gradient-to-br ${benefit.gradient} opacity-0 group-hover:opacity-5 transition-opacity`} />
                <CardContent className="pt-10 pb-10 text-center relative">
                  <div className={`w-20 h-20 mx-auto mb-6 rounded-2xl bg-gradient-to-br ${benefit.gradient} flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform`}>
                    <benefit.icon className="h-10 w-10 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold mb-4 text-foreground">
                    {benefit.title}
                  </h3>
                  <p className="text-muted-foreground leading-relaxed">
                    {benefit.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Passo a Passo - Seção 2 */}
      <section id="passo-a-passo" className="py-20 bg-gradient-to-b from-secondary/30 to-transparent scroll-mt-20">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-extrabold mb-4 text-foreground">
              Passo a Passo do Registro
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Entenda como funciona todo o processo de registro de marcas no INPI
            </p>
          </div>

          {/* Introdução */}
          <div className="max-w-4xl mx-auto mb-16">
            <Card className="border-0 shadow-xl">
              <CardContent className="p-8 md:p-12">
                <h3 className="text-2xl font-bold mb-4 text-primary">Para que serve o registro de marca?</h3>
                <p className="text-muted-foreground leading-relaxed mb-4">
                  A sua marca é o seu nome, é a sua identidade no mercado ou área em que você atua. Por essa razão é muito importante para o seu negócio que a sua marca seja… bem… <strong>SUA!</strong> E para ser sua, primeiro ela precisa estar registrada no INPI.
                </p>
                <div className="bg-primary/5 border-l-4 border-primary p-4 my-6 italic">
                  "No Brasil, segundo a Lei 9.279 de 1996, a propriedade da marca adquire-se pelo registro validamente expedido."
                </div>
                <p className="text-muted-foreground leading-relaxed">
                  Ou seja, a sua marca só passa a ser realmente <strong>SUA</strong> se o INPI primeiro analisar, verificar se ela pode mesmo ser registrada como sua, e expedir um <strong>CERTIFICADO DE REGISTRO</strong>, que é o que garante a sua propriedade sobre ela e, também, exclusividade no uso da marca dentro da sua área de atuação em todo o Brasil.
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Etapas do Processo */}
          <div className="max-w-5xl mx-auto space-y-6">
            {processSteps.map((step, index) => (
              <Card key={index} className="border-0 shadow-xl hover:shadow-2xl transition-all group">
                <CardContent className="p-8">
                  <div className="flex gap-6 items-start">
                    <div className="flex-shrink-0 w-16 h-16 rounded-2xl bg-gradient-to-br from-primary to-purple-600 flex items-center justify-center text-white text-2xl font-extrabold shadow-lg group-hover:scale-110 transition-transform">
                      {step.number}
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl md:text-2xl font-bold mb-3 text-foreground">
                        {step.title}
                      </h3>
                      <p className="text-muted-foreground leading-relaxed">
                        {step.description}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Tempo do Processo */}
          <div className="max-w-4xl mx-auto mt-16">
            <Card className="border-0 shadow-xl bg-gradient-to-br from-accent/5 to-orange-500/5">
              <CardContent className="p-8 md:p-12">
                <h3 className="text-2xl font-bold mb-4 text-accent">Quanto tempo demora esse processo?</h3>
                <p className="text-muted-foreground leading-relaxed mb-4">
                  Um processo sem incidentes atualmente demora em média <strong className="text-foreground">18 meses</strong>. Em casos de oposição, pode se arrastar por alguns anos.
                </p>
                <p className="text-muted-foreground leading-relaxed">
                  <strong className="text-foreground">Isso não acontece com MARCAFACIL.LEGAL!</strong> Temos ferramentas e tecnologias que nos ajudam a monitorar e gerir o seu processo em tempo real e garantir que tudo saia conforme o esperado.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Quero registrar minha marca - Seção 3 */}
      <section id="registrar-marca" className="py-20 scroll-mt-20">
        <div className="container">
          <div className="max-w-4xl mx-auto">
            <Card className="border-0 shadow-3xl relative overflow-hidden group">
              <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-accent/5" />
              <div className="absolute -top-24 -right-24 w-48 h-48 bg-accent/10 rounded-full blur-3xl group-hover:scale-150 transition-transform duration-1000" />
              <CardContent className="p-10 md:p-16 text-center relative">
                <div className="w-24 h-24 mx-auto mb-8 rounded-3xl bg-gradient-to-br from-accent to-orange-500 flex items-center justify-center shadow-2xl animate-bounce">
                  <DollarSign className="h-12 w-12 text-white" />
                </div>
                <h2 className="text-4xl md:text-5xl font-extrabold mb-6 text-foreground">
                  Registro de marca a partir de <span className="bg-gradient-to-r from-accent to-orange-500 bg-clip-text text-transparent whitespace-nowrap">R$ 865</span>
                </h2>
                <p className="text-xl text-muted-foreground mb-10 max-w-2xl mx-auto">
                  Parcelamento disponível no cartão de crédito<br />
                  Consulta gratuita para confirmar valores atualizados e entender todas as etapas do processo.
                </p>
                <Button
                  size="lg"
                  onClick={() => window.open(whatsappUrl, '_blank')}
                  className="h-16 px-10 bg-gradient-to-r from-primary to-purple-600 text-primary-foreground hover:shadow-2xl hover:scale-105 transition-all text-xl font-bold rounded-xl gap-2"
                >
                  <MessageCircle className="h-5 w-5" />
                  <span className="hidden sm:inline">Quero registrar minha marca</span>
                  <span className="sm:hidden">Registrar marca</span>
                  <ArrowRight className="h-5 w-5" />
                </Button>
                <p className="text-sm text-muted-foreground mt-6">
                  ✓ 100% online • ✓ Sem taxas ocultas • ✓ Garantia de aprovação
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Depoimentos - Novo Estilo */}
      <section className="py-16 md:py-20 bg-white">
        <div className="container px-4">
          {/* Header com Estrelas */}
          <div className="text-center mb-12">
            <div className="flex items-center justify-center gap-2 text-[#ff6b35] mb-4">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="h-6 w-6 md:h-8 md:w-8 fill-current" />
              ))}
            </div>
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-extrabold mb-3 text-foreground">
              O Que Nossos <span className="text-[#ff6b35]">Clientes Dizem</span>
            </h2>
            <p className="text-base md:text-lg text-muted-foreground max-w-2xl mx-auto">
              Avaliações reais de clientes satisfeitos com nossos produtos e serviços
            </p>
          </div>

          {/* Widget Trustindex */}
          <div className="max-w-6xl mx-auto mb-12">
            <TrustindexWidget />
          </div>

          {/* Métricas */}
          <div className="max-w-2xl mx-auto">
            <div className="bg-[#fff5f0] border border-[#ff6b35]/20 rounded-2xl p-6 md:p-8">
              <div className="grid grid-cols-2 gap-6 md:gap-8">
                <div className="text-center">
                  <div className="text-3xl md:text-4xl lg:text-5xl font-extrabold text-[#ff6b35] mb-2">
                    4.9/5.0
                  </div>
                  <p className="text-xs md:text-sm text-muted-foreground">
                    Média de avaliações
                  </p>
                </div>
                <div className="text-center">
                  <div className="text-3xl md:text-4xl lg:text-5xl font-extrabold text-[#ff6b35] mb-2">
                    500+
                  </div>
                  <p className="text-xs md:text-sm text-muted-foreground">
                    Avaliações no Google
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-extrabold mb-4 text-foreground">
              Perguntas Frequentes
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Tire suas dúvidas sobre o processo de registro de marcas
            </p>
          </div>

          <div className="max-w-4xl mx-auto">
            <Accordion type="single" collapsible className="space-y-4">
              <AccordionItem value="item-1" className="border-0 shadow-lg rounded-xl overflow-hidden bg-white">
                <AccordionTrigger className="px-6 py-5 hover:no-underline hover:bg-secondary/50 transition-colors">
                  <span className="text-lg font-bold text-left">Quanto tempo demora para registrar uma marca?</span>
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-5 text-muted-foreground leading-relaxed">
                  Um processo sem incidentes demora em média <strong>18 meses</strong>. Em casos de oposição ou exigências técnicas, pode levar mais tempo. Nossa análise prévia de viabilidade minimiza significativamente esses riscos, garantindo um processo mais rápido e tranquilo.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-2" className="border-0 shadow-lg rounded-xl overflow-hidden bg-white">
                <AccordionTrigger className="px-6 py-5 hover:no-underline hover:bg-secondary/50 transition-colors">
                  <span className="text-lg font-bold text-left">Qual é o custo total para registrar uma marca?</span>
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-5 text-muted-foreground leading-relaxed">
                  O registro de marca começa a partir de <strong>R$ 865</strong>, incluindo taxas do INPI e nossos honorários. O valor pode variar dependendo do número de classes e do tipo de marca. <strong>Parcelamento disponível no cartão de crédito.</strong> Oferecemos consulta gratuita para confirmar valores atualizados e sem compromisso.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-3" className="border-0 shadow-lg rounded-xl overflow-hidden bg-white">
                <AccordionTrigger className="px-6 py-5 hover:no-underline hover:bg-secondary/50 transition-colors">
                  <span className="text-lg font-bold text-left">Preciso ter CNPJ para registrar uma marca?</span>
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-5 text-muted-foreground leading-relaxed">
                  Não necessariamente. Tanto <strong>pessoas físicas (CPF)</strong> quanto <strong>pessoas jurídicas (CNPJ)</strong> podem registrar marcas no INPI. Porém, é importante que a atividade da marca esteja relacionada à sua atuação profissional ou empresarial.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-4" className="border-0 shadow-lg rounded-xl overflow-hidden bg-white">
                <AccordionTrigger className="px-6 py-5 hover:no-underline hover:bg-secondary/50 transition-colors">
                  <span className="text-lg font-bold text-left">O que acontece se alguém se opor ao meu registro?</span>
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-5 text-muted-foreground leading-relaxed">
                  Durante o período de oposição (60 dias após publicação), terceiros podem contestar seu pedido. Caso isso ocorra, você terá 60 dias para apresentar uma defesa. Nossa equipe especializada prepara toda a documentação necessária e te orienta em cada etapa do processo de defesa.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-5" className="border-0 shadow-lg rounded-xl overflow-hidden bg-white">
                <AccordionTrigger className="px-6 py-5 hover:no-underline hover:bg-secondary/50 transition-colors">
                  <span className="text-lg font-bold text-left">Posso usar minha marca antes do registro ser aprovado?</span>
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-5 text-muted-foreground leading-relaxed">
                  Sim, você pode usar sua marca durante o processo de registro. Porém, a <strong>proteção legal total</strong> só é garantida após a concessão do certificado pelo INPI. Por isso, é importante iniciar o processo o quanto antes para garantir seus direitos.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-6" className="border-0 shadow-lg rounded-xl overflow-hidden bg-white">
                <AccordionTrigger className="px-6 py-5 hover:no-underline hover:bg-secondary/50 transition-colors">
                  <span className="text-lg font-bold text-left">O registro de marca vale para todo o Brasil?</span>
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-5 text-muted-foreground leading-relaxed">
                  Sim! O registro concedido pelo INPI garante <strong>proteção em todo o território nacional</strong> dentro das classes registradas. Você terá exclusividade no uso da marca em sua área de atuação em todos os estados brasileiros.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-7" className="border-0 shadow-lg rounded-xl overflow-hidden bg-white">
                <AccordionTrigger className="px-6 py-5 hover:no-underline hover:bg-secondary/50 transition-colors">
                  <span className="text-lg font-bold text-left">Por quanto tempo o registro é válido?</span>
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-5 text-muted-foreground leading-relaxed">
                  O registro de marca é válido por <strong>10 anos</strong> a partir da data de concessão. Após esse período, você pode renovar por mais 10 anos, e assim sucessivamente, mantendo sua marca protegida indefinidamente. Te avisamos quando for hora de renovar!
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-8" className="border-0 shadow-lg rounded-xl overflow-hidden bg-white">
                <AccordionTrigger className="px-6 py-5 hover:no-underline hover:bg-secondary/50 transition-colors">
                  <span className="text-lg font-bold text-left">Vocês oferecem garantia de aprovação?</span>
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-5 text-muted-foreground leading-relaxed">
                  Sim! Realizamos uma <strong>análise prévia de viabilidade</strong> completa antes de iniciar o processo. Se identificarmos riscos significativos, orientamos sobre as melhores alternativas. Oferecemos <strong>GARANTIA de aprovação</strong>, resultado de 15 anos de experiência e análise especializada.
                </AccordionContent>
              </AccordionItem>
            </Accordion>

            {/* CTA após FAQ */}
            <div className="mt-12 text-center">
              <p className="text-lg text-muted-foreground mb-6">
                Ainda tem dúvidas? Fale com nossos especialistas!
              </p>
              <Button
                size="lg"
                onClick={() => window.open(whatsappUrl, '_blank')}
                className="h-14 px-8 bg-gradient-to-r from-primary to-purple-600 text-primary-foreground hover:shadow-xl hover:scale-105 transition-all text-lg font-bold gap-2 rounded-xl"
              >
                <MessageCircle className="h-5 w-5" />
                Falar com especialista
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Quero uma consulta gratuita - Seção 4 */}
      <section id="consulta-gratuita" className="relative py-24 overflow-hidden scroll-mt-20">
        <div className="absolute inset-0 bg-gradient-to-br from-primary via-purple-600 to-primary" />
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxwYXRoIGQ9Ik0zNiAxOGMzLjMxNCAwIDYgMi42ODYgNiA2cy0yLjY4NiA2LTYgNi02LTIuNjg2LTYtNiAyLjY4Ni02IDYtNnoiIHN0cm9rZT0iI2ZmZiIgc3Ryb2tlLW9wYWNpdHk9Ii4wNSIvPjwvZz48L3N2Zz4=')] opacity-10" />
        
        <div className="container relative">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-4xl md:text-5xl font-extrabold mb-4 text-white">
                Agende agora sua consulta gratuita com um especialista
              </h2>
              <p className="text-xl text-white/90 mb-2">
                100% gratuita • Sem compromisso • Atendimento especializado
              </p>
            </div>

            <Card className="border-0 shadow-3xl">
              <CardContent className="p-8 md:p-12">
                <form 
                  name="consulta-gratuita" 
                  method="POST" 
                  data-netlify="true" 
                  data-netlify-honeypot="bot-field"
                  onSubmit={handleConsultation} 
                  className="space-y-6"
                >
                  {/* Campo oculto para Netlify Forms */}
                  <input type="hidden" name="form-name" value="consulta-gratuita" />
                  {/* Honeypot anti-spam */}
                  <div className="hidden">
                    <label>Não preencha este campo: <input name="bot-field" /></label>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-semibold text-foreground">Nome completo</label>
                    <Input
                      type="text"
                      name="nome"
                      placeholder="Digite seu nome"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="h-14 text-lg"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-semibold text-foreground">E-mail</label>
                    <Input
                      type="email"
                      name="email"
                      placeholder="seu@email.com"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="h-14 text-lg"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-semibold text-foreground">WhatsApp</label>
                    <Input
                      type="tel"
                      name="whatsapp"
                      placeholder="(00) 00000-0000"
                      value={formData.whatsapp}
                      onChange={(e) => setFormData({ ...formData, whatsapp: e.target.value })}
                      className="h-14 text-lg"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-semibold text-foreground">Nome da marca</label>
                    <Input
                      type="text"
                      name="marca"
                      placeholder="Qual marca deseja registrar?"
                      value={formData.brandName}
                      onChange={(e) => setFormData({ ...formData, brandName: e.target.value })}
                      className="h-14 text-lg"
                      required
                    />
                  </div>
                  <Button
                    type="submit"
                    size="lg"
                    className="w-full h-16 bg-gradient-to-r from-accent to-orange-500 text-accent-foreground hover:shadow-2xl hover:scale-105 transition-all text-lg sm:text-xl font-extrabold rounded-xl"
                  >
                    <span className="hidden sm:inline">Agendar minha consulta gratuita</span>
                    <span className="sm:hidden text-center leading-tight">Agendar consulta<br />gratuita</span>
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer - Design Original */}
      <footer className="bg-[#3a4a5c] text-white py-16">
        <div className="container">
          <div className="grid md:grid-cols-3 gap-12 mb-12">
            {/* Logo e Links Úteis */}
            <div>
              <div className="flex items-center gap-3 mb-6">
                <img src={APP_LOGO_CIRCLE} alt="MarcaFácil.legal" className="w-16 h-16" />
              </div>
              <h3 className="text-[#ff9966] font-bold mb-4 text-lg">Links Úteis</h3>
              <ul className="space-y-3">
                <li>
                  <a href="https://marcafacil.legal/quem-somos" className="text-white/80 hover:text-white transition-colors">
                    QUEM SOMOS
                  </a>
                </li>
                <li>
                  <a href="https://marcafacil.legal/passo-a-passo" className="text-white/80 hover:text-white transition-colors">
                    PASSO A PASSO
                  </a>
                </li>
                <li>
                  <a href="https://marcafacil.legal/quanto-custa" className="text-white/80 hover:text-white transition-colors">
                    QUANTO CUSTA
                  </a>
                </li>
                <li>
                  <a href="https://marcafacil.legal/fale-conosco" className="text-white/80 hover:text-white transition-colors">
                    FALE CONOSCO
                  </a>
                </li>
                <li>
                  <a href="https://marcafacil.legal/politicas" className="text-white/80 hover:text-white transition-colors">
                    POLÍTICA DE TRABALHO
                  </a>
                </li>
              </ul>
            </div>

            {/* Contato */}
            <div>
              <h3 className="text-[#ff9966] font-bold mb-4 text-lg">Contato</h3>
              <ul className="space-y-3">
                <li>
                  <a href="mailto:atendimento@marcafacil.legal" className="text-white/80 hover:text-white transition-colors">
                    atendimento@marcafacil.legal
                  </a>
                </li>
                <li className="text-white/80">
                  (21) 99794-1008
                </li>
              </ul>
            </div>

            {/* Dados Legais */}
            <div>
              <h3 className="text-[#ff9966] font-bold mb-4 text-lg">Dados Legais</h3>
              <div className="space-y-2 text-white/80 text-sm">
                <p className="font-semibold">MARCAFACIL.LEGAL ASSESSORIA</p>
                <p>CONSULTORIA E TECNOLOGIA LTDA</p>
                <p>CNPJ: 61.973.476/0001-01</p>
                <p className="mt-4">Rua Santa Luzia 651, 25º Andar — Centro,</p>
                <p>Rio de Janeiro/RJ</p>
                <p>CEP: 20030-041</p>
              </div>
            </div>
          </div>

          {/* Copyright */}
          <div className="border-t border-white/10 pt-8 text-center">
            <p className="text-white/60 text-sm">
              © 2025 MARCAFACIL.LEGAL — Todos os Direitos Reservados.
            </p>
          </div>
        </div>
      </footer>

      {/* WhatsApp Flutuante */}
      <a
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 z-50 w-16 h-16 bg-[#25D366] rounded-full flex items-center justify-center shadow-2xl hover:scale-110 transition-transform animate-bounce"
        aria-label="WhatsApp"
      >
        <MessageCircle className="h-8 w-8 text-white" />
      </a>
    </div>
  );
}
